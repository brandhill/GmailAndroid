/** Automatically generated file. DO NOT MODIFY */
package uet.dtui.gmail;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}