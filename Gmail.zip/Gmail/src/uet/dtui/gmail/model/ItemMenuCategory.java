package uet.dtui.gmail.model;

public class ItemMenuCategory {
	public String name;
	public int imageName;
	
	public ItemMenuCategory(String title, int image) {
		this.name = title;
		this.imageName = image;
	}
	
}
