package uet.dtui.gmail.model;

public class PairSaving {
	public PairSaving(String str1, String str2){
		title = str1; info = str2;
	}
	public String title;
	public String info;
}
