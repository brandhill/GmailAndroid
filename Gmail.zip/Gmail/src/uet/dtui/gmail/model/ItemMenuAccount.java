package uet.dtui.gmail.model;

public class ItemMenuAccount {
	public Account account;
	
	public ItemMenuAccount(Account acc) {
		this.account = acc;
	}
}
